import streamlit as st
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

st.set_page_config(page_title="Cholera Risk Demo", page_icon="🦠", layout="wide")

st.title("🦠 Cholera Outbreak Predictive Analysis & Surveillance")
st.caption("Demo Streamlit dashboard using sample data — for testing the deployment workflow.")

df = pd.read_csv("bauchi_cholera_demo.csv")

st.sidebar.header("Dashboard")
lga = st.sidebar.selectbox("Select LGA", ["All"] + sorted(df["LGA"].unique().tolist()))

view = df if lga == "All" else df[df["LGA"] == lga]

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Cases", int(view["Cholera_Cases"].sum()))
c2.metric("Deaths", int(view["Cholera_Deaths"].sum()))
c3.metric("LGAs", view["LGA"].nunique())
c4.metric("Avg. Rainfall", f'{view["Rainfall_mm"].mean():.1f} mm')

st.subheader("Weekly Cholera Trend")
trend = view.groupby("Epi_Week", as_index=False)["Cholera_Cases"].sum()
st.line_chart(trend.set_index("Epi_Week"))

st.subheader("Environmental Risk Prediction")

features = [
    "Rainfall_mm", "Temperature_C", "Humidity_pct",
    "Toilet_Access_pct", "Open_Defecation_pct",
    "Health_Facilities", "Population"
]

X = df[features]
y = df["Environmental_Risk"]

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y)

st.write("Enter environmental conditions to test the model:")
col1, col2 = st.columns(2)

with col1:
    rainfall = st.number_input("Rainfall (mm)", 0.0, 500.0, 120.0)
    temperature = st.number_input("Temperature (°C)", 10.0, 45.0, 27.0)
    humidity = st.number_input("Humidity (%)", 0.0, 100.0, 75.0)
    toilet = st.number_input("Toilet Access (%)", 0.0, 100.0, 55.0)

with col2:
    open_def = st.number_input("Open Defecation (%)", 0.0, 100.0, 35.0)
    facilities = st.number_input("Health Facilities", 0, 100, 8)
    population = st.number_input("Population", 1000, 2000000, 250000)

if st.button("Predict Environmental Risk"):
    sample = [[rainfall, temperature, humidity, toilet, open_def, facilities, population]]
    prediction = model.predict(sample)[0]
    probabilities = model.predict_proba(sample)[0]
    confidence = max(probabilities) * 100

    st.success(f"Predicted Risk: **{prediction}**")
    st.info(f"Model confidence: **{confidence:.1f}%**")

st.subheader("Sample Data")
st.dataframe(df, use_container_width=True)
