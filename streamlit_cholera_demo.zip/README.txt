# Streamlit Cholera Demo

This is a SMALL SAMPLE/DEMO dataset created only to let you test how a Streamlit dashboard works.

It is NOT official Bauchi 2023 surveillance data and must NOT be presented as real research data.

## Test locally
1. Install Python.
2. Open a terminal in this folder.
3. Run: pip install -r requirements.txt
4. Run: streamlit run app.py

## Test on Streamlit Community Cloud
1. Create a GitHub repository.
2. Upload app.py, bauchi_cholera_demo.csv and requirements.txt.
3. Sign in to Streamlit Community Cloud.
4. Create a new app and select the GitHub repository.
5. Set the main file to `app.py`.
6. Deploy.
